<?php

namespace App\Http\Controllers;

use App\Category;
use App\Pass;
use App\StockProduct;
use App\Unit;
use Illuminate\Http\Request;

class StockProductController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $models = StockProduct::select('stock_products.*', 'categories.name as categoryName', 'passes.name as passName', 'units.name as UnitName')
            ->leftjoin('categories', 'categories.id', '=', 'stock_products.product_category_id')
            ->leftjoin('passes', 'passes.id', '=', 'stock_products.product_brand_id')
            ->leftjoin('units', 'units.id', '=', 'stock_products.product_unit_id')
            ->whereNull('stock_products.deleted_at')->orderby('stock_products.id', 'desc')
            ->get();


        return view('StockProduct.index', compact('models'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $pdtCatgorys = Category::select('name', 'id')->where('status', 1)->get();
        $pdtUnits = Unit::select('name', 'id')->where('status', 1)->get();
        $pdtBrands = Pass::select('name', 'id')->where('status', 1)->get();

        return view('StockProduct.create', compact('pdtCatgorys', 'pdtUnits', 'pdtBrands'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $model = new StockProduct();
        $model->product_name = $request->product_name;
        $model->product_id = $request->product_id;
        $model->product_brand_id = $request->product_brand_id;
        $model->product_category_id = $request->product_category_id;
        $model->product_unit_id = $request->product_unit_id;
        $model->actual_price = $request->actual_price;
        $model->selling_price = $request->selling_price;
        $model->gst = $request->gst;
        $model->limt = $request->limt;
        $model->status = "1";

        $model->save();
        return redirect()
            ->route('stockproduct.index')
            ->withStatus('Stockproduct Successfully Created.');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\StockProduct  $stockProduct
     * @return \Illuminate\Http\Response
     */
    public function show(StockProduct $stockProduct)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\StockProduct  $stockProduct
     * @return \Illuminate\Http\Response
     */
    public function edit(StockProduct $stockProduct)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\StockProduct  $stockProduct
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, StockProduct $stockProduct)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\StockProduct  $stockProduct
     * @return \Illuminate\Http\Response
     */
    public function destroy(StockProduct $stockProduct)
    {
        //
    }
}
