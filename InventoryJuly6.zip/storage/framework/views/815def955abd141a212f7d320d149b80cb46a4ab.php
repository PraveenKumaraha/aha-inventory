<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">Product Information</h4>
                </div>
                <div class="card-body">
                    <table class="table">
                        <thead>
                            <th>ID</th>
                            <th>Category</th>
                            <th>Name</th>
                            <th>Stock</th>
                            <th>Defective Stock</th>
                            <th>Base price</th>
                            <th>Average Price</th>
                            <th>Total sales</th>
                            <th>Income Produced</th>
                        </thead>
                        <tbody>
                            <tr>
                                <td><?php echo e($product->id); ?></td>
                                <td><a href="<?php echo e(route('categories.show', $product->category)); ?>"><?php echo e($product->category->name); ?></a></td>
                                <td><?php echo e($product->name); ?></td>
                                <td><?php echo e($product->stock); ?></td>
                                <td><?php echo e($product->stock_defective); ?></td>
                                <td><?php echo e(format_money($product->price)); ?></td>
                                <td><?php echo e(format_money($product->solds->avg('price'))); ?></td>
                                <td><?php echo e($product->solds->sum('qty')); ?></td>
                                <td><?php echo e(format_money($product->solds->sum('total_amount'))); ?></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <h4 class="card-title">Latest Sales</h4>
                </div>
                <div class="card-body">
                    <table class="table">
                        <thead>
                            <th>Date</th>
                            <th>Sale ID</th>
                            <th>Quantity</th>
                            <th>Price Unit</th>
                            <th>Total Amount</th>
                            <th></th>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $solds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sold): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e(date('d-m-y', strtotime($sold->created_at))); ?></td>
                                    <td><a href="<?php echo e(route('sales.show', $sold->sale_id)); ?>"><?php echo e($sold->sale_id); ?></a></td>
                                    <td><?php echo e($sold->qty); ?></td>
                                    <td><?php echo e(format_money($sold->price)); ?></td>
                                    <td><?php echo e(format_money($sold->total_amount)); ?></td>
                                    <td class="td-actions text-right">
                                        <a href="<?php echo e(route('sales.show', $sold->sale_id)); ?>" class="btn btn-link" data-toggle="tooltip" data-placement="bottom" title="View Sale">
                                            <i class="tim-icons icon-zoom-split"></i>
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <h4 class="card-title">Latest Receipts</h4>
                </div>
                <div class="card-body">
                    <table class="table">
                        <thead>
                            <th>Date</th>
                            <th>Receipt ID</th>
                            <th>Title</th>
                            <th>Stock</th>
                            <th>Defective Stock</th>
                            <th>Total Stock</th>
                            <th></th>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $receiveds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $received): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e(date('d-m-y', strtotime($received->created_at))); ?></td>
                                    <td><a href="<?php echo e(route('receipts.show', $received->receipt)); ?>"><?php echo e($received->receipt_id); ?></a></td>
                                    <td style="max-width:150px;"><?php echo e($received->receipt->title); ?></td>
                                    <td><?php echo e($received->stock); ?></td>
                                    <td><?php echo e($received->stock_defective); ?></td>
                                    <td><?php echo e($received->stock + $received->stock_defective); ?></td>
                                    <td class="td-actions text-right">
                                        <a href="<?php echo e(route('receipts.show', $received->receipt)); ?>" class="btn btn-link" data-toggle="tooltip" data-placement="bottom" title="Ver Receipt">
                                            <i class="tim-icons icon-zoom-split"></i>
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['page' => 'Product Information', 'pageSlug' => 'products', 'section' => 'inventory'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\aha\laravel-inventory-master\resources\views/inventory/products/show.blade.php ENDPATH**/ ?>